# download.sh is used to
# get some large files (>25M)
# get DatasetB.pkl
mv DatasetB.pkl ./dataset/DatasetB.pkl
# get DatasetC.pkl
mv DatasetC.pkl ./dataset/DatasetC.pkl